//NATALIA SALAZAR
package test;

import modelo.Ventana;

public class App {
    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
    }
}
